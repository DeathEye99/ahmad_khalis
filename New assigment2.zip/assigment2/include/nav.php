<!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand"   href="#">AHMAD KHALIS AFFANDI BIN AHMAD KHAIRRI (AM1801003416)</a>
    </div>
  </nav>
  <br>